package server.api;

import server.auth.Authentication;
import server.auth.Authorized;

import javax.ws.rs.*;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

/**
 * Created by svuatoslav on 10/24/16.
 */
@Path("/data")
public class data {
    @Authorized
    @POST
    @Path("users")
    @Consumes("application/x-www-form-urlencoded")
    @Produces("application/json")
    public Response removeUser() {

        try {
            return Response.ok(Authentication.getUsers()).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }
}
