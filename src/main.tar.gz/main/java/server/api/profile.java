package server.api;

import model.Player;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import server.auth.Authentication;
import server.auth.Authorized;

import javax.ws.rs.*;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

/**
 * Created by svuatoslav on 10/24/16.
 */
@Path("/profile")
public class profile {
    private static final Logger log = LogManager.getLogger(Authentication.class);
    @Authorized
    @POST
    @Path("name")
    @Consumes("application/x-www-form-urlencoded")
    @Produces("text/plain")
    public Response removeUser(ContainerRequestContext requestContext, @FormParam("name") String name) {

        try {

            Long token = Long.parseLong(requestContext.getHeaderString(HttpHeaders.AUTHORIZATION).substring("Bearer".length()).trim());
            Authentication.setName(token,name);
            log.info("User renamed to '{}'",name );
            return Response.ok("Renamed to " + name).build();

        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }
}
