/**
 * This module contains matchmaking engine implementations
 *
 * @author Alpi
 */
package matchmaker;